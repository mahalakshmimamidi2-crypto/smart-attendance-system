# Smart Student Attendance System (MERN)

Requirements: Node.js 18+, MongoDB running locally (or a MongoDB Atlas URI).

## 1. Backend
    cd server
    cp .env.example .env        # edit MONGO_URI if needed
    npm install
    npm run seed                # creates demo users, students, subjects, attendance
    npm start                   # API on http://localhost:5000

## 2. Frontend (new terminal)
    cd client
    npm install
    npm run dev                 # opens http://localhost:5173

## Demo logins
| Role    | Username | Password   |
|---------|----------|------------|
| Admin   | admin    | admin123   |
| Teacher | teacher  | teacher123 |
| Student | cs101    | student123 |

Adding a student in the Admin screen also creates a login: username = roll number (lowercase), password = student123.

## REST API (all except login need `Authorization: Bearer <token>`)
| Method | Endpoint | Roles |
|--------|----------|-------|
| POST | /api/auth/login | all |
| GET | /api/students, /api/subjects | admin, teacher |
| POST, PUT, DELETE | /api/students[/:id], /api/subjects[/:id] | admin |
| GET | /api/attendance?subject=&date= | admin, teacher |
| POST | /api/attendance/bulk | admin, teacher |
| PUT, DELETE | /api/attendance/:id | admin, teacher |
| GET | /api/reports/summary | admin, teacher |
| GET | /api/reports/me | student |

## Running in VS Code
1. File > Open Folder > select `attendance-mern`.
2. Terminal > Run Task > "Install all", then "Install client" (one time).
3. Make sure MongoDB is running, then run task "Seed database" (one time).
4. Run task "Start app (API + client)". The browser opens at http://localhost:5173.
