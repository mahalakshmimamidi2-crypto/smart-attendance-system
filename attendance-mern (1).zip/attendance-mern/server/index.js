require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
app.use(cors());
app.use(express.json());
app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api', require('./routes'));

const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/smart_attendance';
mongoose.connect(uri)
  .then(() => app.listen(process.env.PORT || 5000, () => console.log('API running on port ' + (process.env.PORT || 5000))))
  .catch(e => { console.error('MongoDB connection failed:', e.message); process.exit(1); });
