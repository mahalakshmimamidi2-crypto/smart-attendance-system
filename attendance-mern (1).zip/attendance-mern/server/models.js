const mongoose = require('mongoose');
const { Schema, model } = mongoose;

const User = model('User', new Schema({
  name: { type: String, required: true },
  username: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['admin', 'teacher', 'student'], required: true },
  student: { type: Schema.Types.ObjectId, ref: 'Student' }
}));

const Student = model('Student', new Schema({
  name: { type: String, required: true, trim: true },
  rollNo: { type: String, required: true, unique: true, trim: true },
  department: { type: String, default: 'CSE', trim: true }
}));

const Subject = model('Subject', new Schema({
  name: { type: String, required: true, trim: true },
  code: { type: String, required: true, unique: true, trim: true }
}));

const attSchema = new Schema({
  student: { type: Schema.Types.ObjectId, ref: 'Student', required: true },
  subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
  date: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ },
  status: { type: String, enum: ['present', 'absent'], required: true },
  markedBy: { type: Schema.Types.ObjectId, ref: 'User' }
});
attSchema.index({ student: 1, subject: 1, date: 1 }, { unique: true });
const Attendance = model('Attendance', attSchema);

module.exports = { User, Student, Subject, Attendance };
