const jwt = require('jsonwebtoken');
const SECRET = () => process.env.JWT_SECRET || 'dev_secret';

const sign = u => jwt.sign({ id: u._id, role: u.role, student: u.student || null }, SECRET(), { expiresIn: '8h' });

const auth = (req, res, next) => {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  try { req.user = jwt.verify(t, SECRET()); next(); }
  catch { res.status(401).json({ message: 'Please sign in again' }); }
};

const allow = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : res.status(403).json({ message: 'Not allowed for your role' });

module.exports = { sign, auth, allow };
