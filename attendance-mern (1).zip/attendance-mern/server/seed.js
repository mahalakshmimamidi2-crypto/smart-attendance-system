require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { User, Student, Subject, Attendance } = require('./models');

(async () => {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/smart_attendance');
  await Promise.all([User.deleteMany(), Student.deleteMany(), Subject.deleteMany(), Attendance.deleteMany()]);
  const hash = p => bcrypt.hash(p, 10);
  await User.create([
    { name: 'Admin', username: 'admin', password: await hash('admin123'), role: 'admin' },
    { name: 'Prof. Teacher', username: 'teacher', password: await hash('teacher123'), role: 'teacher' }
  ]);
  const names = ['Aarav Reddy', 'Diya Sharma', 'Karthik Rao', 'Meera Iyer', 'Rohan Gupta', 'Sana Khan'];
  const students = [];
  for (let i = 0; i < names.length; i++) {
    const s = await Student.create({ name: names[i], rollNo: 'CS' + (101 + i), department: 'CSE' });
    await User.create({ name: s.name, username: s.rollNo, password: await hash('student123'), role: 'student', student: s._id });
    students.push(s);
  }
  const subjects = await Subject.create([
    { name: 'Data Structures', code: 'CS201' }, { name: 'Database Systems', code: 'CS205' }, { name: 'Web Technologies', code: 'CS210' }
  ]);
  const recs = []; const d = new Date(); let n = 0;
  while (n < 8) {
    d.setDate(d.getDate() - 1);
    if (d.getDay() % 6 === 0) continue;
    n++;
    const date = d.toISOString().slice(0, 10);
    subjects.forEach((u, j) => students.forEach((s, i) =>
      recs.push({ student: s._id, subject: u._id, date, status: (i * 5 + j * 3 + n * 7) % (i === 2 ? 3 : 9) !== 0 ? 'present' : 'absent' })));
  }
  await Attendance.insertMany(recs);
  console.log('Seeded. Logins: admin/admin123, teacher/teacher123, cs101/student123');
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
