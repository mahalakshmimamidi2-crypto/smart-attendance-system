const express = require('express');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');
const { User, Student, Subject, Attendance } = require('./models');
const { sign, auth, allow } = require('./auth');

const r = express.Router();
const h = fn => (req, res) => fn(req, res).catch(e =>
  res.status(e.code === 11000 ? 409 : 500).json({ message: e.code === 11000 ? 'That roll number / code already exists' : e.message }));
const pc = (p, t) => (t ? Math.round((p * 100) / t) : 0);

// ---- Auth ----
r.post('/auth/login', h(async (req, res) => {
  const { username = '', password = '' } = req.body;
  const u = await User.findOne({ username: username.toLowerCase().trim() });
  if (!u || !(await bcrypt.compare(password, u.password)))
    return res.status(401).json({ message: 'Wrong username or password' });
  res.json({ token: sign(u), user: { name: u.name, role: u.role, student: u.student || null } });
}));

// ---- Students (CRUD) ----
r.get('/students', auth, allow('admin', 'teacher'), h(async (req, res) => res.json(await Student.find().sort('rollNo'))));
r.post('/students', auth, allow('admin'), h(async (req, res) => {
  const { name, rollNo, department } = req.body;
  const s = await Student.create({ name, rollNo, department });
  await User.create({ name, username: rollNo, password: await bcrypt.hash('student123', 10), role: 'student', student: s._id });
  res.status(201).json(s);
}));
r.put('/students/:id', auth, allow('admin'), h(async (req, res) => {
  const { name, rollNo, department } = req.body;
  const s = await Student.findByIdAndUpdate(req.params.id, { name, rollNo, department }, { new: true, runValidators: true });
  if (!s) return res.status(404).json({ message: 'Student not found' });
  await User.updateOne({ student: s._id }, { name });
  res.json(s);
}));
r.delete('/students/:id', auth, allow('admin'), h(async (req, res) => {
  await Attendance.deleteMany({ student: req.params.id });
  await User.deleteOne({ student: req.params.id });
  await Student.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
}));

// ---- Subjects (CRUD) ----
r.get('/subjects', auth, allow('admin', 'teacher'), h(async (req, res) => res.json(await Subject.find().sort('code'))));
r.post('/subjects', auth, allow('admin'), h(async (req, res) => res.status(201).json(await Subject.create({ name: req.body.name, code: req.body.code }))));
r.put('/subjects/:id', auth, allow('admin'), h(async (req, res) => {
  const s = await Subject.findByIdAndUpdate(req.params.id, { name: req.body.name, code: req.body.code }, { new: true, runValidators: true });
  if (!s) return res.status(404).json({ message: 'Subject not found' });
  res.json(s);
}));
r.delete('/subjects/:id', auth, allow('admin'), h(async (req, res) => {
  await Attendance.deleteMany({ subject: req.params.id });
  await Subject.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
}));

// ---- Attendance ----
r.get('/attendance', auth, allow('admin', 'teacher'), h(async (req, res) => {
  const q = {};
  if (req.query.subject) q.subject = req.query.subject;
  if (req.query.date) q.date = req.query.date;
  res.json(await Attendance.find(q).populate('student', 'name rollNo').populate('subject', 'name code').sort({ date: -1 }).limit(200));
}));
r.post('/attendance/bulk', auth, allow('admin', 'teacher'), h(async (req, res) => {
  const { subject, date, records } = req.body;
  if (!subject || !/^\d{4}-\d{2}-\d{2}$/.test(date || '') || !Array.isArray(records))
    return res.status(400).json({ message: 'subject, date (YYYY-MM-DD) and records are required' });
  await Attendance.bulkWrite(records.map(x => ({
    updateOne: {
      filter: { student: x.student, subject, date },
      update: { $set: { status: x.status === 'absent' ? 'absent' : 'present', markedBy: req.user.id } },
      upsert: true
    }
  })));
  res.json({ saved: records.length });
}));
r.put('/attendance/:id', auth, allow('admin', 'teacher'), h(async (req, res) => {
  const a = await Attendance.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true, runValidators: true });
  if (!a) return res.status(404).json({ message: 'Record not found' });
  res.json(a);
}));
r.delete('/attendance/:id', auth, allow('admin', 'teacher'), h(async (req, res) => {
  await Attendance.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
}));

// ---- Reports ----
async function buildReport(studentId) {
  const sf = studentId ? { _id: studentId } : {};
  const af = studentId ? { student: new mongoose.Types.ObjectId(studentId) } : {};
  const [students, subjects, agg] = await Promise.all([
    Student.find(sf).sort('rollNo').lean(),
    Subject.find().sort('code').lean(),
    Attendance.aggregate([
      { $match: af },
      { $group: { _id: { s: '$student', u: '$subject' }, present: { $sum: { $cond: [{ $eq: ['$status', 'present'] }, 1, 0] } }, total: { $sum: 1 } } }
    ])
  ]);
  const cell = {};
  agg.forEach(a => { cell[`${a._id.s}_${a._id.u}`] = a; });
  const rows = students.map(st => {
    let P = 0, T = 0;
    const bySubject = subjects.map(u => {
      const c = cell[`${st._id}_${u._id}`] || { present: 0, total: 0 };
      P += c.present; T += c.total;
      return { subject: u._id, present: c.present, total: c.total, percent: pc(c.present, c.total) };
    });
    return { _id: st._id, name: st.name, rollNo: st.rollNo, bySubject, present: P, total: T, percent: pc(P, T) };
  });
  const subjectStats = subjects.map((u, i) => {
    let P = 0, T = 0;
    rows.forEach(x => { P += x.bySubject[i].present; T += x.bySubject[i].total; });
    return { _id: u._id, name: u.name, code: u.code, percent: pc(P, T) };
  });
  const P = rows.reduce((a, x) => a + x.present, 0), T = rows.reduce((a, x) => a + x.total, 0);
  return { students: rows, subjects: subjectStats, overall: pc(P, T), lowCount: rows.filter(x => x.total && x.percent < 75).length };
}
r.get('/reports/summary', auth, allow('admin', 'teacher'), h(async (req, res) => res.json(await buildReport())));
r.get('/reports/me', auth, allow('student'), h(async (req, res) => {
  if (!req.user.student) return res.status(404).json({ message: 'No student profile linked' });
  res.json(await buildReport(req.user.student));
}));

module.exports = r;
