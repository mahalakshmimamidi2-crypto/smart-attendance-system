import { useState, useEffect, useCallback } from 'react';
import { api } from './api';

const today = () => new Date().toISOString().slice(0, 10);
const cls = v => (v >= 75 ? 'ok' : v >= 60 ? 'warn' : 'bad');
const TABS = {
  admin: [['rep', 'Reports'], ['students', 'Students'], ['subjects', 'Subjects'], ['rec', 'Records']],
  teacher: [['mark', 'Mark attendance'], ['rec', 'Records'], ['rep', 'Reports']],
  student: [['rep', 'My attendance']]
};
const CFG = {
  students: { title: 'Students', fields: [['name', 'Name'], ['rollNo', 'Roll no'], ['department', 'Department']] },
  subjects: { title: 'Subjects', fields: [['name', 'Name'], ['code', 'Code']] }
};

function Login({ onLogin }) {
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [err, setErr] = useState('');
  const submit = async e => {
    e.preventDefault();
    try {
      const d = await api('/auth/login', 'POST', { username: u, password: p });
      localStorage.setItem('token', d.token);
      localStorage.setItem('user', JSON.stringify(d.user));
      onLogin(d.user);
    } catch (x) { setErr(x.message); }
  };
  return (
    <form className="card login" onSubmit={submit}>
      <h1>Attend<span>IQ</span></h1>
      <p className="hint">Smart student attendance system</p>
      <label>Username<input value={u} onChange={e => setU(e.target.value)} autoComplete="username" /></label>
      <label>Password<input type="password" value={p} onChange={e => setP(e.target.value)} autoComplete="current-password" /></label>
      {err && <p className="chip bad">{err}</p>}
      <button className="btn">Sign in</button>
      <p className="hint">Demo: admin / admin123, teacher / teacher123, cs101 / student123</p>
    </form>
  );
}

function Stat({ n, l }) { return <div className="stat"><b>{n}</b><small>{l}</small></div>; }

function Reports({ role }) {
  const [d, setD] = useState(null);
  const [err, setErr] = useState('');
  useEffect(() => { api(role === 'student' ? '/reports/me' : '/reports/summary').then(setD).catch(e => setErr(e.message)); }, [role]);
  if (err) return <p className="chip bad">{err}</p>;
  if (!d) return <p>Loading…</p>;
  return (
    <>
      <div className="grid">
        <Stat n={d.students.length} l="Students" /><Stat n={d.subjects.length} l="Subjects" />
        <Stat n={d.overall + '%'} l="Overall attendance" /><Stat n={d.lowCount} l="Below 75%" />
      </div>
      <div className="card"><h3>Attendance by subject</h3>
        {d.subjects.map(s => (
          <div className="bar" key={s._id}><span>{s.name}</span><i style={{ '--w': s.percent + '%' }} /><b>{s.percent}%</b></div>
        ))}
      </div>
      <div className="card"><h3>Student-wise report</h3>
        <div className="tw"><table>
          <thead><tr><th>Student</th>{d.subjects.map(s => <th key={s._id}>{s.code}</th>)}<th>Overall</th><th>Status</th></tr></thead>
          <tbody>{d.students.map(s => (
            <tr key={s._id}>
              <td>{s.name} <span className="hint">{s.rollNo}</span></td>
              {s.bySubject.map(b => <td key={b.subject}>{b.percent}%</td>)}
              <td>{s.percent}%</td>
              <td><span className={'chip ' + cls(s.percent)}>{s.total ? (s.percent >= 75 ? 'Good' : 'Shortage') : 'No data'}</span></td>
            </tr>))}
          </tbody>
        </table></div>
      </div>
    </>
  );
}

function Mark() {
  const [students, setStudents] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [sub, setSub] = useState('');
  const [date, setDate] = useState(today());
  const [marks, setMarks] = useState({});
  const [msg, setMsg] = useState('');
  useEffect(() => {
    Promise.all([api('/students'), api('/subjects')]).then(([a, b]) => { setStudents(a); setSubjects(b); if (b[0]) setSub(b[0]._id); }).catch(e => setMsg(e.message));
  }, []);
  useEffect(() => {
    if (!sub) return;
    api(`/attendance?subject=${sub}&date=${date}`).then(rs => {
      const m = {}; rs.forEach(r => { m[r.student._id] = r.status; }); setMarks(m);
    }).catch(() => {});
  }, [sub, date]);
  const save = async () => {
    try {
      await api('/attendance/bulk', 'POST', { subject: sub, date, records: students.map(s => ({ student: s._id, status: marks[s._id] || 'present' })) });
      setMsg('Attendance saved');
    } catch (e) { setMsg(e.message); }
    setTimeout(() => setMsg(''), 2500);
  };
  return (
    <div className="card"><h3>Mark attendance</h3>
      <div className="row">
        <select value={sub} onChange={e => setSub(e.target.value)}>{subjects.map(s => <option key={s._id} value={s._id}>{s.name}</option>)}</select>
        <input type="date" value={date} max={today()} onChange={e => setDate(e.target.value || today())} />
        <button className="btn s" onClick={() => setMarks(Object.fromEntries(students.map(s => [s._id, 'present'])))}>All present</button>
      </div>
      <div className="tw"><table>
        <thead><tr><th>Roll</th><th>Student</th><th>Status</th></tr></thead>
        <tbody>{students.map(s => {
          const ok = (marks[s._id] || 'present') === 'present';
          return (
            <tr key={s._id}><td>{s.rollNo}</td><td>{s.name}</td>
              <td>
                <button className={'btn ' + (ok ? '' : 's')} onClick={() => setMarks({ ...marks, [s._id]: 'present' })}>Present</button>{' '}
                <button className={'btn ' + (ok ? 's' : 'd')} onClick={() => setMarks({ ...marks, [s._id]: 'absent' })}>Absent</button>
              </td></tr>);
        })}</tbody>
      </table></div>
      <p><button className="btn" onClick={save} disabled={!sub}>Save attendance</button> <span className="hint">{msg}</span></p>
    </div>
  );
}

function Records() {
  const [list, setList] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [sub, setSub] = useState('');
  const [date, setDate] = useState('');
  const [err, setErr] = useState('');
  const load = useCallback(() => {
    const q = new URLSearchParams(); if (sub) q.set('subject', sub); if (date) q.set('date', date);
    api('/attendance?' + q).then(setList).catch(e => setErr(e.message));
  }, [sub, date]);
  useEffect(() => { api('/subjects').then(setSubjects).catch(() => {}); }, []);
  useEffect(load, [load]);
  const toggle = async r => { await api('/attendance/' + r._id, 'PUT', { status: r.status === 'present' ? 'absent' : 'present' }); load(); };
  const del = async r => { if (confirm('Delete this record?')) { await api('/attendance/' + r._id, 'DELETE'); load(); } };
  return (
    <div className="card"><h3>Attendance records</h3>
      <div className="row">
        <select value={sub} onChange={e => setSub(e.target.value)}><option value="">All subjects</option>{subjects.map(s => <option key={s._id} value={s._id}>{s.name}</option>)}</select>
        <input type="date" value={date} onChange={e => setDate(e.target.value)} />
        <button className="btn s" onClick={() => { setSub(''); setDate(''); }}>Clear</button>
      </div>
      {err && <p className="chip bad">{err}</p>}
      <div className="tw"><table>
        <thead><tr><th>Date</th><th>Subject</th><th>Student</th><th>Status</th><th></th></tr></thead>
        <tbody>{list.map(r => (
          <tr key={r._id}><td>{r.date}</td><td>{r.subject?.name}</td><td>{r.student?.name}</td>
            <td><span className={'chip ' + (r.status === 'present' ? 'ok' : 'bad')}>{r.status}</span></td>
            <td><button className="btn s" onClick={() => toggle(r)}>Change</button>{' '}<button className="btn d" onClick={() => del(r)}>Delete</button></td></tr>))}
          {!list.length && <tr><td colSpan="5" className="hint">No records match.</td></tr>}
        </tbody>
      </table></div>
      <p className="hint">Showing the latest 200 matching records.</p>
    </div>
  );
}

function Manage({ kind }) {
  const cfg = CFG[kind];
  const [list, setList] = useState([]);
  const [f, setF] = useState({});
  const [err, setErr] = useState('');
  const load = useCallback(() => api('/' + kind).then(setList).catch(e => setErr(e.message)), [kind]);
  useEffect(() => { setF({}); setErr(''); load(); }, [load]);
  const add = async () => { try { await api('/' + kind, 'POST', f); setF({}); setErr(''); load(); } catch (e) { setErr(e.message); } };
  const edit = async x => {
    const body = {};
    for (const [k, l] of cfg.fields) { const v = prompt(l, x[k] || ''); body[k] = v === null ? x[k] : v; }
    try { await api(`/${kind}/${x._id}`, 'PUT', body); load(); } catch (e) { setErr(e.message); }
  };
  const del = async x => { if (confirm(`Delete ${x.name} and its attendance records?`)) { await api(`/${kind}/${x._id}`, 'DELETE'); load(); } };
  return (
    <div className="card"><h3>{cfg.title}</h3>
      <div className="row">
        {cfg.fields.map(([k, l]) => <input key={k} placeholder={l} value={f[k] || ''} onChange={e => setF({ ...f, [k]: e.target.value })} />)}
        <button className="btn" onClick={add}>Add</button>
      </div>
      {kind === 'students' && <p className="hint">A login is created automatically: username = roll number, password = student123.</p>}
      {err && <p className="chip bad">{err}</p>}
      <div className="tw"><table>
        <thead><tr>{cfg.fields.map(([k, l]) => <th key={k}>{l}</th>)}<th></th></tr></thead>
        <tbody>{list.map(x => (
          <tr key={x._id}>{cfg.fields.map(([k]) => <td key={k}>{x[k]}</td>)}
            <td><button className="btn s" onClick={() => edit(x)}>Edit</button>{' '}<button className="btn d" onClick={() => del(x)}>Delete</button></td></tr>))}
        </tbody>
      </table></div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(() => { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } });
  const [tab, setTab] = useState('');
  useEffect(() => { if (user) setTab(TABS[user.role][0][0]); }, [user]);
  const logout = () => { localStorage.clear(); setUser(null); };
  if (!user) return <Login onLogin={setUser} />;
  return (
    <>
      <header>
        <div className="brand">Attend<span>IQ</span></div>
        <div>{user.name} ({user.role}) <button className="btn s" onClick={logout}>Sign out</button></div>
      </header>
      <nav>{TABS[user.role].map(([id, label]) => <button key={id} className={id === tab ? 'on' : ''} onClick={() => setTab(id)}>{label}</button>)}</nav>
      <main>
        {tab === 'rep' && <Reports role={user.role} />}
        {tab === 'mark' && <Mark />}
        {tab === 'rec' && <Records />}
        {(tab === 'students' || tab === 'subjects') && <Manage key={tab} kind={tab} />}
      </main>
    </>
  );
}
